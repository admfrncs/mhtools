import express, { Request, Response, NextFunction } from "express";
import { registerRoutes } from "./routes";
import { setupVite, serveStaticFiles, log } from "./vite";

const app = express();

// Logging middleware should be first
app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }

      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "…";
      }
      log(logLine);
    }
  });

  next();
});

// Body parsing middleware should come before route registration
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// Register API routes
registerRoutes(app);

// Error handling middleware should be last
app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
  const status = err.status || err.statusCode || 500;
  const message = err.message || "Internal Server Error";

  console.error(err); // Log the error for debugging
  res.status(status).json({ message });
});

// Self-invoking async function to start the server
(async () => {
  // Start the Express server
  const server = app.listen(5000, "0.0.0.0", () => {
    log("Server is running on http://localhost:5000");
  });

  // Setup Vite for development environment
  if (app.get("env") === "development") {
    await setupVite(app);
  } else {
    serveStaticFiles(app);
  }
})();
