import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertMoodSchema, insertSymptomSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  app.post("/api/mood-assessments", async (req, res) => {
    try {
      const assessment = insertMoodSchema.parse(req.body);
      const result = await storage.createMoodAssessment(assessment);
      res.json(result);
    } catch (error) {
      res.status(400).json({ error: "Invalid assessment data" });
    }
  });

  app.get("/api/mood-assessments", async (_req, res) => {
    const assessments = await storage.getMoodAssessments();
    res.json(assessments);
  });

  app.post("/api/symptom-assessments", async (req, res) => {
    try {
      const assessment = insertSymptomSchema.parse(req.body);
      const result = await storage.createSymptomAssessment(assessment);
      res.json(result);
    } catch (error) {
      res.status(400).json({ error: "Invalid assessment data" });
    }
  });

  app.get("/api/symptom-assessments", async (_req, res) => {
    const assessments = await storage.getSymptomAssessments();
    res.json(assessments);
  });

  return createServer(app);
}
