import express, { type Express, type Request, type Response, type NextFunction } from "express";
import fs from "fs";
import path, { dirname } from "path";
import { fileURLToPath } from "url";
import { createServer as createViteServer, createLogger, type UserConfig } from "vite";
import serveStatic from "serve-static";
import viteConfig from "../vite.config"; // Ensure correct path

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const viteLogger = createLogger();

// Logging function
export function log(message: string, source = "express") {
  const formattedTime = new Date().toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    second: "2-digit",
    hour12: true,
  });

  console.log(`${formattedTime} [${source}] ${message}`);
}

// Function to setup Vite for development
export async function setupVite(app: Express) {
  try {
    const vite = await createViteServer({
      ...(viteConfig as UserConfig),
      configFile: false,
      customLogger: viteLogger,
    });

    app.use(vite.middlewares);

    app.use("*", async (req: Request, res: Response, next: NextFunction) => {
      try {
        const url = req.originalUrl;
        const indexPath = path.resolve(__dirname, "index.html");

        if (!fs.existsSync(indexPath)) {
          throw new Error("index.html not found");
        }

        let template = await vite.transformIndexHtml(url, fs.readFileSync(indexPath, "utf-8"));
        const entryServerPath = path.resolve(viteConfig.root ?? process.cwd(), "src/entry-server.ts");

        if (!fs.existsSync(entryServerPath)) {
          throw new Error(`entry-server.ts not found at ${entryServerPath}`);
        }

        const entryModule = await vite.ssrLoadModule(entryServerPath);
        if (typeof entryModule?.default !== "function") {
          throw new Error("entry-server.ts must export a default function");
        }

        const appHtml = await entryModule.default(url);
        res.status(200).set({ "Content-Type": "text/html" }).end(template.replace("<!--ssr-outlet-->", appHtml));
      } catch (error) {
        viteLogger.error(`Error rendering page: ${error}`);
        res.status(500).end("Internal Server Error");
      }
    });

    log("Vite server is set up", "Vite");
  } catch (error) {
    throw new Error(`Failed to setup Vite: ${error}`);
  }
}
