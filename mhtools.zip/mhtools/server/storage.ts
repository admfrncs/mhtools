import {
  type MoodAssessment,
  type SymptomAssessment,
  type InsertMoodAssessment,
  type InsertSymptomAssessment,
} from "@shared/schema";
import { PrismaClient } from "@prisma/client";

// Ensure a single Prisma instance to avoid connection issues
const prisma = new PrismaClient();

export interface IStorage {
  createMoodAssessment(assessment: InsertMoodAssessment): Promise<MoodAssessment>;
  getMoodAssessments(): Promise<MoodAssessment[]>;
  createSymptomAssessment(assessment: InsertSymptomAssessment): Promise<SymptomAssessment>;
  getSymptomAssessments(): Promise<SymptomAssessment[]>;
}

export class PrismaStorage implements IStorage {
  private prisma = prisma;

  async createMoodAssessment(assessment: InsertMoodAssessment): Promise<MoodAssessment> {
    if (!assessment || !Array.isArray(assessment.responses)) {
      throw new Error("Invalid mood assessment: 'responses' must be an array of numbers.");
    }

    const responses = assessment.responses.map(value => {
      const numValue = Number(value);
      if (isNaN(numValue)) {
        throw new Error("All responses must be valid numbers.");
      }
      return numValue;
    });

    if (responses.length === 0) {
      throw new Error("Responses cannot be empty.");
    }

    return await this.prisma.moodAssessment.create({
      data: {
        responses,
        overallScore: responses.reduce((sum, score) => sum + score, 0),
        sectionScores: assessment.sectionScores ?? [],
        createdAt: new Date(),
      },
    });
  }

  async getMoodAssessments(): Promise<MoodAssessment[]> {
    return await this.prisma.moodAssessment.findMany();
  }

  async createSymptomAssessment(assessment: InsertSymptomAssessment): Promise<SymptomAssessment> {
    if (!assessment || typeof assessment !== "object") {
      throw new Error("Invalid symptom assessment data.");
    }

    return await this.prisma.symptomAssessment.create({
      data: {
        ...assessment,
        createdAt: new Date(),
      },
    });
  }

  async getSymptomAssessments(): Promise<SymptomAssessment[]> {
    return await this.prisma.symptomAssessment.findMany();
  }
}

// Ensure Prisma disconnects when the app exits
process.on("beforeExit", async () => {
  await prisma.$disconnect();
});

export const storage = new PrismaStorage();
