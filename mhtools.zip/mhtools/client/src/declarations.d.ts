declare module 'input-otp';
