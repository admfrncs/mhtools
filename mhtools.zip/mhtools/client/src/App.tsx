import React from 'react';
import { Switch, Route } from 'wouter';  // For routing
import { QueryClientProvider } from '@tanstack/react-query'; // For query client provider
import { queryClient } from './lib/queryClient'; // Adjust path as necessary
import { Toaster } from '@/components/ui/toaster'; // Assuming this is your Toaster component
import Home from '@/pages/home'; // Adjust path as necessary
import MoodTracker from '@/pages/mood-tracker'; // Adjust path as necessary
import SymptomTracker from '@/pages/symptom-tracker'; // Adjust path as necessary
import NotFound from '@/pages/not-found'; // Adjust path as necessary
import Drawer from '@/components/ui/drawer'; // Adjusted path to match your folder structure

// Import OTPInputProvider to wrap your components that will use the OTP context
import { OTPInputProvider } from './components/ui/input-otp'; // Correct path to input-otp

const App = () => {
  return (
    <QueryClientProvider client={queryClient}>
      {/* Drawer component without background scaling prop */}
      <Drawer />
      
      {/* Wrap the routing section or specific components with OTPInputProvider */}
      <OTPInputProvider>
        <Switch>
          <Route path="/" component={Home} />
          <Route path="/mood-tracker" component={MoodTracker} />
          <Route path="/symptom-tracker" component={SymptomTracker} />
          <Route component={NotFound} />
        </Switch>
      </OTPInputProvider>

      {/* Toast notifications */}
      <Toaster />
    </QueryClientProvider>
  );
};

export default App;
