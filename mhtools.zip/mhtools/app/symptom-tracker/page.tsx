'use client';

import { useState } from "react";
import { useRouter } from "next/navigation";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { symptomCategories, severityLevels } from "@/lib/symptoms";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";

// ✅ Fix: Import or define apiRequest
import { apiRequest } from "@/lib/api"; // Make sure this path is correct

type SelectedSymptom = {
  category: string;
  symptom: string;
  severity: string;
};

export default function SymptomTracker() {
  const router = useRouter();
  const { toast } = useToast();
  const [selectedSymptoms, setSelectedSymptoms] = useState<SelectedSymptom[]>([]);
  const [showResults, setShowResults] = useState(false);
  const [isLoading, setIsLoading] = useState(false); // Loading state

  const saveMutation = useMutation({
    mutationFn: async (data: any) => {
      return await apiRequest("POST", "/api/symptom-assessments", data);
    },
    onMutate: () => setIsLoading(true), // Set loading to true when the mutation starts
    onSuccess: () => setIsLoading(false), // Set loading to false on success
    onError: () => setIsLoading(false), // Set loading to false on error
  });

  const toggleSymptom = (category: string, symptom: string) => {
    const exists = selectedSymptoms.find(
      s => s.category === category && s.symptom === symptom
    );

    if (exists) {
      setSelectedSymptoms(selectedSymptoms.filter(s => s !== exists));
    } else {
      setSelectedSymptoms([
        ...selectedSymptoms,
        { category, symptom, severity: "Mild" }
      ]);
    }
  };

  const updateSeverity = (symptom: SelectedSymptom, severity: string) => {
    setSelectedSymptoms(selectedSymptoms.map(s =>
      s === symptom ? { ...s, severity } : s
    ));
  };

  const handleFinish = async () => {
    try {
      await saveMutation.mutateAsync({
        date: new Date(),
        symptoms: selectedSymptoms
      });

      setShowResults(true);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to save assessment",
        variant: "destructive"
      });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted p-4">
      <Card className="max-w-2xl mx-auto mt-8">
        <CardContent className="p-6">
          <h2 className="text-2xl font-bold mb-6">Symptom Assessment</h2>
          <p className="text-muted-foreground mb-6">
            Please check all symptoms you have experienced in the past 6 months
          </p>

          <Accordion type="single" collapsible className="w-full">
            {symptomCategories.map(category => (
              <AccordionItem key={category.name} value={category.name}>
                <AccordionTrigger>{category.name}</AccordionTrigger>
                <AccordionContent>
                  <div className="space-y-4">
                    {category.symptoms.map(symptom => {
                      const selected = selectedSymptoms.find(
                        s => s.category === category.name && s.symptom === symptom
                      );

                      return (
                        <div key={symptom} className="flex items-center gap-4">
                          <Checkbox
                            checked={!!selected}
                            onCheckedChange={() =>
                              toggleSymptom(category.name, symptom)
                            }
                          />
                          <span className="flex-grow">{symptom}</span>
                          {selected && (
                            <Select
                              value={selected.severity}
                              onValueChange={(value) =>
                                updateSeverity(selected, value)
                              }
                            >
                              <SelectTrigger className="w-[100px]">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                {severityLevels.map(level => (
                                  <SelectItem key={level} value={level}>
                                    {level}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>

          <Button
            className="mt-8 w-full"
            onClick={handleFinish}
            disabled={selectedSymptoms.length === 0 || isLoading}
          >
            {isLoading ? 'Saving...' : 'Complete Assessment'}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
} 
