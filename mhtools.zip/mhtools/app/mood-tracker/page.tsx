'use client';

import { useState } from 'react';
import { useRouter } from 'next/router';
import { Button } from '@/components/ui/';  // Assuming Button is located in client/src/components/ui/button.tsx
import { Card, CardContent } from '@/components/ui/card';  // Assuming Card is located in client/src/components/ui/card.tsx
import { sections, sectionDisplayNames, questions, getScoreRating } from '@/lib/questions';  // Adjust the path accordingly if needed
import { useToast } from '@/hooks/use-toast';  // Assuming useToast is located in client/src/hooks/use-toast.ts
import { format } from 'date-fns';
import * as XLSX from 'xlsx';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';  // Assuming Popover is located in client/src/components/ui/popover.tsx
import { Calendar } from '@/components/ui/calendar';  // Assuming Calendar is located in client/src/components/ui/calendar.tsx
import { CalendarIcon } from 'lucide-react';

const FILE_NAME = 'mental-health-assessment.xlsx';

export default function MoodTracker() {
  const router = useRouter(); // Use Next.js router
  const { toast } = useToast();
  const [date, setDate] = useState<string>(format(new Date(), 'PPP'));
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [responses, setResponses] = useState<number[]>([]);
  const [showResults, setShowResults] = useState(false);

  const handleAnswer = (score: number) => {
    const newResponses = [...responses, score];
    setResponses(newResponses);

    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      setShowResults(true);
    }
  };

  const calculateSectionScores = () => {
    const sectionScores = new Array(5).fill(0);
    responses.forEach((score, index) => {
      const sectionIndex = Math.floor(index / 4);
      sectionScores[sectionIndex] += score;
    });
    return sectionScores;
  };

  const calculateOverallScore = (sectionScores: number[]) => {
    return sectionScores.reduce((acc, score) => acc + score, 0);
  };

  const startNewAssessment = () => {
    setCurrentQuestion(0);
    setResponses([]);
    setShowResults(false);
    setDate(format(new Date(), 'PPP'));
    router.push('/'); // Navigate back to home page
  };

  const exportToExcel = async () => {
    if (responses.length === 0) {
      toast({
        title: 'Error',
        description: 'Please complete the assessment before exporting.',
        variant: 'destructive',
      });
      return;
    }

    const sectionScores = calculateSectionScores();
    const overallScore = calculateOverallScore(sectionScores);

    try {
      const wb = XLSX.utils.book_new();
      const wsData = [
        ['Date', new Date().toISOString()],
        ['Overall Score', overallScore],
        ...sectionScores.map((score, index) => [
          `Section ${index + 1} Score`,
          score,
        ]),
      ];

      const ws = XLSX.utils.aoa_to_sheet(wsData);
      XLSX.utils.book_append_sheet(wb, ws, 'Assessment Results');
      XLSX.writeFile(wb, FILE_NAME);

      toast({
        title: 'Success',
        description: 'Assessment data exported successfully',
      });
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to export assessment data',
        variant: 'destructive',
      });
    }
  };

  if (showResults) {
    const sectionScores = calculateSectionScores();
    const overallScore = calculateOverallScore(sectionScores);

    return (
      <div className="min-h-screen bg-gradient-to-b from-background to-muted p-4">
        <Card className="max-w-2xl mx-auto mt-8">
          <CardContent className="p-6">
            <h2 className="text-2xl font-bold mb-6">Assessment Results</h2>

            <div className="space-y-4">
              <div className="p-4 bg-primary/10 rounded-lg">
                <h3 className="font-semibold">Overall Score: {overallScore}</h3>
                <p className="text-sm text-muted-foreground">
                  Rating: {getScoreRating(overallScore)}
                </p>
              </div>

              {sectionScores.map((score, index) => (
                <div key={index} className="p-4 bg-muted rounded-lg">
                  <h4 className="font-medium">{sectionDisplayNames[index]}</h4>
                  <p className="text-sm">Score: {score}</p>
                  <p className="text-sm text-muted-foreground">
                    Rating: {getScoreRating(score)}
                  </p>
                </div>
              ))}
            </div>

            <div className="flex gap-4 mt-8">
              <Button onClick={exportToExcel}>Export to Excel</Button>
              <Button variant="outline" onClick={startNewAssessment}>
                Start New Assessment
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted p-4">
      <Card className="max-w-2xl mx-auto mt-8">
        <CardContent className="p-6">
          <div className="mb-6">
            <h2 className="text-lg font-medium mb-2">Select Date</h2>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className="w-full justify-start text-left font-normal"
                  aria-label="Select date"
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {date}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0">
                <Calendar
                  mode="single"
                  selected={new Date(date)}
                  onSelect={(newDate) => newDate && setDate(format(newDate, 'PPP'))}
                  initialFocus
                  aria-label="Calendar"
                />
              </PopoverContent>
            </Popover>
          </div>

          <div className="mt-8">
            <p className="text-sm text-muted-foreground mb-2">
              Section: {sections[Math.floor(currentQuestion / 4)]}
            </p>
            <h3 className="text-xl font-semibold mb-4">
              {questions[currentQuestion].text}
            </h3>

            <div className="grid gap-3">
              {questions[currentQuestion].options.map((option, index) => (
                <Button
                  key={index}
                  variant="outline"
                  className="justify-start h-auto py-3"
                  onClick={() => handleAnswer(option.score)}
                  aria-label={`Select answer: ${option.text}`}
                >
                  {option.text}
                </Button>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
