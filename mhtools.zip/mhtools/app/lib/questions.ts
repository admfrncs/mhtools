// We'll create a separate array for section names without citations
export const sectionDisplayNames = [
  "Mood & Emotional Regulation",
  "Anxiety & Cognitive Functioning",
  "Physical Symptoms",
  "Sleep & Energy",
  "Behavioral & Social Symptoms"
];

export const sections = [
  "Mood & Emotional Regulation (MDQ – Hirschfeld et al., 2000)",
  "Anxiety & Cognitive Functioning (BAI – Beck et al., 1988, PANSS – Kay et al., 1987)",
  "Physical Symptoms (SSS-8 – Gierk et al., 2014, SSRI Discontinuation Syndrome – Rosenbaum et al., 1998)",
  "Sleep & Energy (PSQI – Buysse et al., 1989, Nightmare Distress & Sleep Disturbance – Krakow et al., 2002)",
  "Behavioral & Social Symptoms (BDI-II – Beck et al., 1996, BIS – Patton et al., 1995, ASRS – Kessler et al., 2005)"
];

// Rest of the questions array remains the same...
[Same content as before for questions array]

export const getScoreRating = (score: number) => {
  if (score <= 8) return "Minimal";
  if (score <= 12) return "Mild";
  if (score <= 16) return "Moderate";
  if (score <= 20) return "Severe";
  return "Extreme";
};
