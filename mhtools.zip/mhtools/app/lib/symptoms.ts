// Move symptoms.ts to Next.js app directory
export const symptomCategories = [
  {
    name: "Mood-Related Symptoms",
    symptoms: [
      "Persistent sadness or low mood",
      "Feeling empty or hopeless",
      "Loss of interest in activities (anhedonia)",
      "Excessive guilt or worthlessness",
      "Mood swings (highs and lows)",
      "Irritability or anger outbursts",
      "Feeling euphoric or excessively happy",
      "Increased energy or restlessness"
    ]
  },
  // ... [Rest of the categories remain the same]
];

export const severityLevels = [
  "Mild",
  "Moderate",
  "Severe"
];
