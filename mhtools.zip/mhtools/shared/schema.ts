import { pgTable, text, serial, integer, date, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const moodAssessments = pgTable("mood_assessments", {
  id: serial("id").primaryKey(),
  date: date("date").notNull(),
  overallScore: integer("overall_score").notNull(),
  sectionScores: json("section_scores").$type<number[]>().notNull(),
  responses: json("responses").$type<number[]>().notNull(),
});

export const symptomAssessments = pgTable("symptom_assessments", {
  id: serial("id").primaryKey(),
  date: date("date").notNull(),
  symptoms: json("symptoms").$type<{category: string, symptom: string, severity: string}[]>().notNull()
});

export const insertMoodSchema = createInsertSchema(moodAssessments);
export const insertSymptomSchema = createInsertSchema(symptomAssessments);

export type InsertMoodAssessment = z.infer<typeof insertMoodSchema>;
export type InsertSymptomAssessment = z.infer<typeof insertSymptomSchema>;
export type MoodAssessment = typeof moodAssessments.$inferSelect;
export type SymptomAssessment = typeof symptomAssessments.$inferSelect;
